README

To play crazy 8s against the computer:
	Run the program driver.py under python 2.  The program will ask if you
	want to be player 0 or 1.  Player 0 starts the game.  When it is your
	turn to move, the program will provide you a list of possible moves.
	To make a move, type the number that appears next to your move choice
	and press enter.
	
TEAM MEMBERS:
Sean Papay - 007323511
Dakota Polenz - 007879664
Ryan Lichtig - 007264348
